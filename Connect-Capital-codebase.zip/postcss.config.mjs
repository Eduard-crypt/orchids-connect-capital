const config = {
<<<<<<< Updated upstream
  plugins: ["@tailwindcss/postcss"],
=======
  plugins: {
    "@tailwindcss/postcss": {},
  },
>>>>>>> Stashed changes
};

export default config;
